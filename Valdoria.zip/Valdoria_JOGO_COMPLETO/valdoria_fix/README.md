# Valdoria — Jogo com Algoritmos Computacionais

## Gênero
Aventura / exploração com coleta de itens. O jogo **não é survivor**. O jogador explora o mapa, coleta itens, derrota slimes e usa o inventário para armazenar os recursos encontrados.

## Como rodar
1. Abra o Godot 4.6 ou superior.
2. Clique em **Importar**.
3. Selecione o arquivo `project.godot` da pasta do projeto.
4. Abra e execute o projeto.
5. A cena inicial é o menu principal. Clique em **Jogar** para entrar no mapa.

## Controles
- **WASD / Setas**: mover personagem
- **Q**: atacar
- **E**: abrir/fechar inventário
- **R**: recalcular/desenhar rota TSP dos itens no mapa
- **O**: ordenar inventário por nome usando QuickSort, com o inventário aberto

## Algoritmos implementados

### 1. TSP — Travelling Salesman Problem
Arquivo principal: `algorithms/tsp_solver.gd`

O TSP é usado para calcular a melhor rota de coleta dos itens espalhados pelo mapa. O jogador pode apertar **R** para recalcular a rota. A lógica do TSP continua implementada no código, mas a linha visual foi desativada para não poluir a tela do jogo.

- Para até 15 pontos: usa solução exata com programação dinâmica estilo Held-Karp.
- Para mais de 15 pontos: usa heurística de Vizinho Mais Próximo com melhoria 2-opt.
- Integração no gameplay: os itens coletáveis do grupo `item` são usados como pontos da rota.

Complexidade:
- Exata: `O(n² · 2ⁿ)`
- Heurística: aproximadamente `O(n²)` por iteração de melhoria

### 2. Inventário com HashMap / Dictionary
Arquivo principal: `characters/scripts/inventario.gd`

O inventário usa `Dictionary`, equivalente a uma HashMap, para armazenar os itens por ID único.

Operações implementadas:
- adicionar item;
- remover item;
- consultar por ID;
- consultar por nome;
- exibir inventário;
- mover itens entre slots;
- receber recompensas de quest, como COIN.

### 3. Coleta de itens
Arquivo principal: `characters/scripts/drop_item.gd`

A coleta está integrada ao gameplay. Quando o jogador encosta em um item no chão, o item chama `add_item()` no personagem, que encaminha a coleta para o inventário. Assim, o item entra na HashMap do inventário.

### 4. Segundo problema computacional — Ordenação com QuickSort
Arquivo principal: `characters/scripts/inventario.gd`

Foi adicionado um segundo algoritmo: **ordenação do inventário com QuickSort**. Com o inventário aberto, o jogador aperta **O** e os itens são organizados por nome.

A ordenação altera apenas a ordem visual dos slots. A estrutura principal continua sendo a HashMap `inventario`.

Complexidade média:
- `O(n log n)`

## Arquivos principais alterados/adicionados
- `algorithms/tsp_solver.gd`
- `characters/scripts/algorithm_gameplay_manager.gd`
- `characters/scripts/inventario.gd`
- `levels/scenes/test_level.tscn`
- `project.godot`
- `docs/ALGORITMOS.md`
- `docs/ISSUES_GITHUB.md`

## Observação para apresentação
O projeto atende aos requisitos porque possui:
- TSP funcional e visível no mapa;
- inventário implementado com HashMap/Dictionary;
- coleta real de itens no gameplay;
- segundo problema computacional integrado: QuickSort no inventário;
- documentação e issues prontas para organizar o repositório Git.

## {quest da Merry}
A personagem **Merry** agora possui uma quest repetível:

- Objetivo: derrotar **5 slimes**.
- HUD: a quest aparece em um painel no canto superior direito da tela.
- Recompensa: ao completar, o jogador recebe **+1 COIN** no inventário.
- A quest reinicia automaticamente, permitindo ganhar mais COIN a cada 5 slimes derrotados.

Arquivos principais da quest:
- `characters/scripts/algorithm_gameplay_manager.gd`
- `characters/scripts/mensageiro.gd`
- `characters/scripts/slime.gd`
- `characters/assets/coin.png`

## Atualização: Mercador, espada melhorada e vida dos slimes

- Foi adicionada uma barraquinha de venda longe da casa principal.
- O Mercador oferece a **Espada de Aço** ao jogador quando ele se aproxima.
- A compra custa **3 COIN**.
- A Espada de Aço aumenta o dano do jogador em **15%**.
- O dano inicial é 10 e o dano com a espada melhorada passa para 11.5.
- Os slimes agora possuem **20 de vida**, então morrem com **2 espadadas** da espada inicial.
- A barra de vida dos slimes só aparece quando eles recebem dano.

### Ajuste visual do mercador e dos slimes
- O mercador agora aparece como NPC visível no mapa, ao lado da própria barraquinha.
- A barraquinha de venda fica como objeto visível no cenário.
- A barra de vida do slime foi reduzida para ficar proporcional, aparecendo apenas quando ele leva dano.


### Ajuste: barraca acessível e novo NPC mercador
- A barraca foi reposicionada para uma área acessível dentro do mapa, abaixo da região da casa.
- O mercador agora usa um sprite próprio: `characters/assets/merchant_npc.png`.
- Ele não reutiliza os NPCs já existentes, como Merry/Mensageiro.
- A compra da Espada de Aço continua funcionando ao chegar perto da barraca e escolher **SIM** ou **NÃO**.


## Atualização: problemas computacionais em grafos

Foi adicionada uma demonstração direta dos problemas pedidos para o artigo/trabalho.

Tecla nova:
- **G**: alternar entre os problemas computacionais aplicados no mapa.

Problemas adicionados:
- caminho mínimo: Dijkstra;
- caminho máximo: DFS limitada;
- fluxo mínimo/custo mínimo: menor caminho sucessivo;
- fluxo máximo: Edmonds-Karp;
- cobertura pequena: Set Cover guloso;
- cobertura grande: Maximum Coverage guloso;
- circuito: rota fechada de patrulha.

Arquivos adicionados/alterados:
- `algorithms/graph_problems.gd`
- `characters/scripts/algorithm_gameplay_manager.gd`
- `docs/PROBLEMAS_COMPUTACIONAIS_APLICADOS.md`
- `project.godot`

Na apresentação, explique que o mapa foi modelado como grafo: os pontos importantes do jogo são os vértices, e as ligações entre regiões são as arestas. Assim, os algoritmos deixam de ser apenas teoria e viram mecânicas de jogo.
