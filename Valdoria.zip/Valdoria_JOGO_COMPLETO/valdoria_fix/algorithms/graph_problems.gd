extends RefCounted
class_name GraphProblems

# ============================================================
# PROBLEMAS COMPUTACIONAIS EM GRAFOS
# ============================================================
# Este arquivo concentra algoritmos clássicos para o artigo:
# - caminho mínimo;
# - caminho máximo simples;
# - fluxo máximo;
# - fluxo mínimo / custo mínimo;
# - cobertura pequena;
# - cobertura grande;
# - circuito.
# ============================================================

const INF: float = 1.0e20


func caminho_minimo(grafo: Dictionary, origem: String, destino: String) -> Dictionary:
	# Dijkstra simples usando varredura linear.
	# Complexidade: O(V² + E), suficiente para o mapa pequeno do jogo.
	var dist: Dictionary = {}
	var anterior: Dictionary = {}
	var visitados: Dictionary = {}

	for no in grafo.keys():
		dist[no] = INF
		anterior[no] = ""
		visitados[no] = false

	if not grafo.has(origem) or not grafo.has(destino):
		return {"caminho": [], "custo": INF, "algoritmo": "Dijkstra"}

	dist[origem] = 0.0

	while true:
		var atual := ""
		var melhor := INF

		for no in grafo.keys():
			if not bool(visitados[no]) and float(dist[no]) < melhor:
				melhor = float(dist[no])
				atual = str(no)

		if atual == "" or atual == destino:
			break

		visitados[atual] = true
		var vizinhos: Dictionary = grafo.get(atual, {})

		for vizinho in vizinhos.keys():
			var novo_custo: float = float(dist[atual]) + float(vizinhos[vizinho])
			if novo_custo < float(dist.get(vizinho, INF)):
				dist[vizinho] = novo_custo
				anterior[vizinho] = atual

	var caminho: Array[String] = []
	var cursor := destino

	if float(dist[destino]) >= INF:
		return {"caminho": [], "custo": INF, "algoritmo": "Dijkstra"}

	while cursor != "":
		caminho.push_front(cursor)
		cursor = str(anterior.get(cursor, ""))

	return {"caminho": caminho, "custo": float(dist[destino]), "algoritmo": "Dijkstra"}


func caminho_maximo_simples(grafo: Dictionary, origem: String, destino: String, limite_vertices: int = 9) -> Dictionary:
	# Procura o maior caminho SEM repetir vértices.
	# Para evitar travar o jogo, limita a quantidade de vértices visitados.
	var melhor: Dictionary = {"caminho": [], "custo": -INF}

	_dfs_caminho_maximo(grafo, origem, destino, {}, [], 0.0, limite_vertices, melhor)

	return {
		"caminho": melhor.get("caminho", []),
		"custo": float(melhor.get("custo", -INF)),
		"algoritmo": "DFS com limite"
	}


func _dfs_caminho_maximo(
	grafo: Dictionary,
	atual: String,
	destino: String,
	visitados: Dictionary,
	caminho_atual: Array,
	custo_atual: float,
	limite_vertices: int,
	melhor: Dictionary
) -> void:
	if caminho_atual.size() >= limite_vertices:
		return

	visitados[atual] = true
	caminho_atual.append(atual)

	if atual == destino:
		if custo_atual > float(melhor.get("custo", -INF)):
			melhor["custo"] = custo_atual
			var copia: Array[String] = []
			for p in caminho_atual:
				copia.append(str(p))
			melhor["caminho"] = copia
	else:
		var vizinhos: Dictionary = grafo.get(atual, {})
		for vizinho in vizinhos.keys():
			var v := str(vizinho)
			if not bool(visitados.get(v, false)):
				_dfs_caminho_maximo(
					grafo,
					v,
					destino,
					visitados,
					caminho_atual,
					custo_atual + float(vizinhos[vizinho]),
					limite_vertices,
					melhor
				)

	caminho_atual.pop_back()
	visitados[atual] = false


func fluxo_maximo(capacidades: Dictionary, origem: String, destino: String) -> Dictionary:
	# Edmonds-Karp: BFS repetida sobre a rede residual.
	var residual := _copiar_rede(capacidades)
	var fluxo_total := 0.0
	var caminhos: Array = []

	while true:
		var busca := _bfs_fluxo(residual, origem, destino)
		var caminho: Array = busca.get("caminho", [])

		if caminho.is_empty():
			break

		var gargalo := INF
		for i in range(caminho.size() - 1):
			var u: String = caminho[i]
			var v: String = caminho[i + 1]
			gargalo = min(gargalo, float(residual[u][v]))

		for i in range(caminho.size() - 1):
			var u2: String = caminho[i]
			var v2: String = caminho[i + 1]
			residual[u2][v2] = float(residual[u2][v2]) - gargalo
			if not residual.has(v2):
				residual[v2] = {}
			residual[v2][u2] = float(residual[v2].get(u2, 0.0)) + gargalo

		fluxo_total += gargalo
		caminhos.append({"caminho": caminho, "fluxo": gargalo})

	return {"fluxo": fluxo_total, "caminhos": caminhos, "algoritmo": "Edmonds-Karp"}


func fluxo_custo_minimo(capacidades: Dictionary, custos: Dictionary, origem: String, destino: String, demanda: float) -> Dictionary:
	# Versão didática: envia fluxo sempre pelo caminho de menor custo disponível.
	# Usa Dijkstra sobre arestas com capacidade residual positiva.
	var residual := _copiar_rede(capacidades)
	var fluxo_enviado := 0.0
	var custo_total := 0.0
	var caminhos: Array = []

	while fluxo_enviado < demanda:
		var grafo_custo: Dictionary = {}

		for u in residual.keys():
			grafo_custo[u] = {}
			var vizinhos: Dictionary = residual[u]
			for v in vizinhos.keys():
				if float(vizinhos[v]) > 0.0:
					grafo_custo[u][v] = float(custos.get(u, {}).get(v, 1.0))

		var menor := caminho_minimo(grafo_custo, origem, destino)
		var caminho: Array = menor.get("caminho", [])
		if caminho.is_empty():
			break

		var gargalo := demanda - fluxo_enviado
		for i in range(caminho.size() - 1):
			var a: String = caminho[i]
			var b: String = caminho[i + 1]
			gargalo = min(gargalo, float(residual[a][b]))

		for i in range(caminho.size() - 1):
			var a2: String = caminho[i]
			var b2: String = caminho[i + 1]
			residual[a2][b2] = float(residual[a2][b2]) - gargalo
			custo_total += gargalo * float(custos.get(a2, {}).get(b2, 1.0))

		fluxo_enviado += gargalo
		caminhos.append({"caminho": caminho, "fluxo": gargalo})

	return {
		"fluxo": fluxo_enviado,
		"custo": custo_total,
		"demanda": demanda,
		"caminhos": caminhos,
		"algoritmo": "Menor caminho sucessivo"
	}


func cobertura_pequena(universo: Array, conjuntos: Dictionary) -> Dictionary:
	# Set Cover guloso: escolhe poucos pontos que cobrem tudo.
	var descobertos: Dictionary = {}
	for elemento in universo:
		descobertos[str(elemento)] = true

	var escolhidos: Array[String] = []

	while not descobertos.is_empty():
		var melhor_nome := ""
		var melhor_cobre: Array[String] = []

		for nome in conjuntos.keys():
			if escolhidos.has(str(nome)):
				continue

			var cobre_agora: Array[String] = []
			for elemento in conjuntos[nome]:
				var e := str(elemento)
				if descobertos.has(e):
					cobre_agora.append(e)

			if cobre_agora.size() > melhor_cobre.size():
				melhor_nome = str(nome)
				melhor_cobre = cobre_agora

		if melhor_nome == "":
			break

		escolhidos.append(melhor_nome)
		for elemento_coberto in melhor_cobre:
			descobertos.erase(elemento_coberto)

	return {"escolhidos": escolhidos, "faltando": descobertos.keys(), "algoritmo": "Set Cover guloso"}


func cobertura_grande(universo: Array, conjuntos: Dictionary, limite: int) -> Dictionary:
	# Maximum Coverage guloso: com poucos pontos, cobre o máximo possível.
	var cobertos: Dictionary = {}
	var escolhidos: Array[String] = []

	for rodada in range(limite):
		var melhor_nome := ""
		var melhor_ganho := -1

		for nome in conjuntos.keys():
			if escolhidos.has(str(nome)):
				continue

			var ganho := 0
			for elemento in conjuntos[nome]:
				var e := str(elemento)
				if not cobertos.has(e):
					ganho += 1

			if ganho > melhor_ganho:
				melhor_ganho = ganho
				melhor_nome = str(nome)

		if melhor_nome == "" or melhor_ganho <= 0:
			break

		escolhidos.append(melhor_nome)
		for elemento2 in conjuntos[melhor_nome]:
			cobertos[str(elemento2)] = true

	return {
		"escolhidos": escolhidos,
		"cobertos": cobertos.keys(),
		"total_coberto": cobertos.size(),
		"total_universo": universo.size(),
		"algoritmo": "Maximum Coverage guloso"
	}


func circuito_vizinho_mais_proximo(origem: String, pontos: Dictionary) -> Dictionary:
	# Circuito estilo patrulha: começa em um nó, visita todos e volta.
	if not pontos.has(origem):
		return {"circuito": [], "distancia": 0.0, "algoritmo": "Vizinho mais próximo"}

	var restantes: Array[String] = []
	for nome in pontos.keys():
		if str(nome) != origem:
			restantes.append(str(nome))

	var circuito: Array[String] = [origem]
	var atual := origem
	var distancia_total := 0.0

	while not restantes.is_empty():
		var melhor_idx := 0
		var melhor_dist := INF

		for i in range(restantes.size()):
			var candidato := restantes[i]
			var d := _distancia_pontos(pontos[atual], pontos[candidato])
			if d < melhor_dist:
				melhor_dist = d
				melhor_idx = i

		var escolhido := restantes[melhor_idx]
		distancia_total += melhor_dist
		circuito.append(escolhido)
		atual = escolhido
		restantes.remove_at(melhor_idx)

	distancia_total += _distancia_pontos(pontos[atual], pontos[origem])
	circuito.append(origem)

	return {"circuito": circuito, "distancia": distancia_total, "algoritmo": "Circuito heurístico"}


func _distancia_pontos(a: Variant, b: Variant) -> float:
	if a is Vector2 and b is Vector2:
		var pos_a: Vector2 = a
		var pos_b: Vector2 = b
		return pos_a.distance_to(pos_b)
	return 0.0


func _copiar_rede(rede: Dictionary) -> Dictionary:
	var copia: Dictionary = {}
	for u in rede.keys():
		copia[u] = {}
		var vizinhos: Dictionary = rede[u]
		for v in vizinhos.keys():
			copia[u][v] = float(vizinhos[v])
	return copia


func _bfs_fluxo(residual: Dictionary, origem: String, destino: String) -> Dictionary:
	var fila: Array[String] = [origem]
	var anterior: Dictionary = {origem: ""}

	while not fila.is_empty():
		var atual: String = str(fila.pop_front())
		var vizinhos: Dictionary = residual.get(atual, {})

		for vizinho in vizinhos.keys():
			var v := str(vizinho)
			if anterior.has(v):
				continue
			if float(vizinhos[vizinho]) <= 0.0:
				continue

			anterior[v] = atual
			if v == destino:
				var caminho: Array[String] = []
				var cursor := destino
				while cursor != "":
					caminho.push_front(cursor)
					cursor = str(anterior.get(cursor, ""))
				return {"caminho": caminho}

			fila.append(v)

	return {"caminho": []}
