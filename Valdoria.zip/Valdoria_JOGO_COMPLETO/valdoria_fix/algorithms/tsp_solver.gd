extends RefCounted
class_name TSPSolver

# ============================================================
# TRAVELLING SALESMAN PROBLEM (TSP)
# ============================================================
# Recebe uma posição inicial e uma lista de pontos de coleta.
# Retorna a menor rota que passa por todos os pontos e volta ao início.
#
# Para poucos pontos, usa solução exata por Programação Dinâmica
# inspirada no Held-Karp: O(n² * 2ⁿ).
# Para muitos pontos, usa heurística: Vizinho Mais Próximo + 2-opt.
# ============================================================

const INF = 1.0e20

var limite_exato: int = 15


func resolver(inicio: Vector2, pontos: Array) -> Dictionary:
	var pontos_limpos: Array[Vector2] = []

	for ponto in pontos:
		if ponto is Vector2:
			pontos_limpos.append(ponto)

	if pontos_limpos.is_empty():
		return {
			"metodo": "sem_pontos",
			"ordem": [],
			"rota": [inicio],
			"distancia": 0.0
		}

	if pontos_limpos.size() <= limite_exato:
		return _resolver_exato_held_karp(inicio, pontos_limpos)

	return _resolver_heuristico(inicio, pontos_limpos)


func _resolver_exato_held_karp(inicio: Vector2, pontos: Array[Vector2]) -> Dictionary:
	var n := pontos.size()
	var dp: Dictionary = {}
	var pai: Dictionary = {}

	for i in range(n):
		var mascara := 1 << i
		var chave := _chave_estado(mascara, i)
		dp[chave] = inicio.distance_to(pontos[i])
		pai[chave] = -1

	for mascara in range(1, 1 << n):
		for ultimo in range(n):
			if (mascara & (1 << ultimo)) == 0:
				continue

			var chave_atual := _chave_estado(mascara, ultimo)
			if not dp.has(chave_atual):
				continue

			var custo_atual: float = float(dp[chave_atual])

			for proximo in range(n):
				if (mascara & (1 << proximo)) != 0:
					continue

				var nova_mascara := mascara | (1 << proximo)
				var nova_chave := _chave_estado(nova_mascara, proximo)
				var novo_custo := custo_atual + pontos[ultimo].distance_to(pontos[proximo])

				if not dp.has(nova_chave) or novo_custo < float(dp[nova_chave]):
					dp[nova_chave] = novo_custo
					pai[nova_chave] = ultimo

	var mascara_final := (1 << n) - 1
	var melhor_custo := INF
	var melhor_ultimo := -1

	for ultimo in range(n):
		var chave_final := _chave_estado(mascara_final, ultimo)
		if not dp.has(chave_final):
			continue

		var custo_total := float(dp[chave_final]) + pontos[ultimo].distance_to(inicio)
		if custo_total < melhor_custo:
			melhor_custo = custo_total
			melhor_ultimo = ultimo

	var ordem: Array[int] = []
	var mascara_reconstrucao := mascara_final
	var atual := melhor_ultimo

	while atual != -1:
		ordem.push_front(atual)
		var chave_reconstrucao := _chave_estado(mascara_reconstrucao, atual)
		var anterior: int = int(pai.get(chave_reconstrucao, -1))
		mascara_reconstrucao = mascara_reconstrucao ^ (1 << atual)
		atual = anterior

	return {
		"metodo": "Held-Karp exato",
		"ordem": ordem,
		"rota": _montar_rota(inicio, pontos, ordem),
		"distancia": melhor_custo
	}


func _resolver_heuristico(inicio: Vector2, pontos: Array[Vector2]) -> Dictionary:
	var ordem := _vizinho_mais_proximo(inicio, pontos)
	ordem = _melhorar_2opt(inicio, pontos, ordem)

	return {
		"metodo": "Heurística: vizinho mais próximo + 2-opt",
		"ordem": ordem,
		"rota": _montar_rota(inicio, pontos, ordem),
		"distancia": _calcular_distancia_rota(inicio, pontos, ordem)
	}


func _vizinho_mais_proximo(inicio: Vector2, pontos: Array[Vector2]) -> Array[int]:
	var restantes: Array[int] = []
	for i in range(pontos.size()):
		restantes.append(i)

	var ordem: Array[int] = []
	var atual := inicio

	while not restantes.is_empty():
		var melhor_indice_lista := 0
		var melhor_distancia := INF

		for i in range(restantes.size()):
			var indice_ponto: int = restantes[i]
			var distancia := atual.distance_to(pontos[indice_ponto])

			if distancia < melhor_distancia:
				melhor_distancia = distancia
				melhor_indice_lista = i

		var escolhido: int = restantes[melhor_indice_lista]
		ordem.append(escolhido)
		atual = pontos[escolhido]
		restantes.remove_at(melhor_indice_lista)

	return ordem


func _melhorar_2opt(inicio: Vector2, pontos: Array[Vector2], ordem_inicial: Array[int]) -> Array[int]:
	var ordem: Array[int] = ordem_inicial.duplicate()
	var melhorou := true

	while melhorou:
		melhorou = false
		for i in range(0, ordem.size() - 1):
			for k in range(i + 1, ordem.size()):
				var candidata := _inverter_trecho(ordem, i, k)
				if _calcular_distancia_rota(inicio, pontos, candidata) < _calcular_distancia_rota(inicio, pontos, ordem):
					ordem = candidata
					melhorou = true

	return ordem


func _inverter_trecho(ordem: Array[int], inicio_trecho: int, fim_trecho: int) -> Array[int]:
	var nova: Array[int] = []

	for i in range(0, inicio_trecho):
		nova.append(ordem[i])

	for i in range(fim_trecho, inicio_trecho - 1, -1):
		nova.append(ordem[i])

	for i in range(fim_trecho + 1, ordem.size()):
		nova.append(ordem[i])

	return nova


func _calcular_distancia_rota(inicio: Vector2, pontos: Array[Vector2], ordem: Array[int]) -> float:
	if ordem.is_empty():
		return 0.0

	var total := 0.0
	var atual := inicio

	for indice in ordem:
		total += atual.distance_to(pontos[indice])
		atual = pontos[indice]

	total += atual.distance_to(inicio)
	return total


func _montar_rota(inicio: Vector2, pontos: Array[Vector2], ordem: Array[int]) -> Array[Vector2]:
	var rota: Array[Vector2] = [inicio]

	for indice in ordem:
		rota.append(pontos[indice])

	rota.append(inicio)
	return rota


func _chave_estado(mascara: int, ultimo: int) -> String:
	return str(mascara) + "|" + str(ultimo)
