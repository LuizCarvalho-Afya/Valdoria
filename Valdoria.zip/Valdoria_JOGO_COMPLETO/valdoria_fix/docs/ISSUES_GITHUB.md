# Issues do projeto Valdoria

Este arquivo lista todas as issues criadas para o projeto, com status e descrição resumida.
As issues devem ser criadas na aba **Issues** do repositório Git para cumprir o requisito da atividade.

---

| # | Título | Labels | Status |
|---|--------|--------|--------|
| 01 | Implementar TSP para cálculo da rota ótima de coleta | algoritmo, gameplay, mapa | ✅ Fechada |
| 02 | Implementar sistema de inventário com HashMap | inventário, algoritmo, gameplay | ✅ Fechada |
| 03 | Implementar coleta de itens no gameplay | gameplay, inventário | ✅ Fechada |
| 04 | Implementar QuickSort para ordenar o inventário | algoritmo, inventário, gameplay | ✅ Fechada |
| 05 | Documentar algoritmos e execução do projeto | documentação | ✅ Fechada |
| 06 | Implementar quest da NPC Merry com recompensa COIN | gameplay, inventário | ✅ Fechada |
| 07 | Implementar mercador, Espada de Aço e balanceamento de combate | gameplay, inventário | ✅ Fechada |
| 08 | Reposicionar barraca e criar sprite do mercador | gameplay, bug | ✅ Fechada |
| 09 | Implementar problemas computacionais em grafos no gameplay | algoritmo, gameplay, mapa | ✅ Fechada |

---

## Como criar as issues no GitHub

1. Acesse o repositório no GitHub.
2. Clique na aba **Issues**.
3. Clique em **New issue**.
4. Copie o título e o conteúdo de cada arquivo em `docs/issues/`.
5. Adicione as labels correspondentes (criar as labels antes se necessário: `algoritmo`, `gameplay`, `inventário`, `mapa`, `bug`, `documentação`).
6. Após implementar, feche a issue com um comentário de conclusão.

## Labels usadas

| Label | Cor sugerida | Uso |
|---|---|---|
| `algoritmo` | Azul | Issues relacionadas a algoritmos computacionais |
| `gameplay` | Verde | Mecânicas e funcionalidades do jogo |
| `inventário` | Amarelo | Sistema de inventário |
| `mapa` | Laranja | Mapa, posicionamento e TSP |
| `bug` | Vermelho | Correções e ajustes |
| `documentação` | Cinza | README, docs e comentários |
