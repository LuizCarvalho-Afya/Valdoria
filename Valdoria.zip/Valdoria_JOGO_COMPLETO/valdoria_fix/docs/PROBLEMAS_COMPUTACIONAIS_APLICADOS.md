# Problemas computacionais aplicados ao jogo Valdoria

Este documento mostra como os problemas pedidos pelo professor foram aplicados no jogo.

Arquivo principal dos algoritmos: `algorithms/graph_problems.gd`  
Arquivo de integração no mapa: `characters/scripts/algorithm_gameplay_manager.gd`  
Tecla de demonstração no jogo: **G**

Ao apertar **G**, o jogo alterna entre as demonstrações de cada problema computacional. Quando o problema envolve rota no mapa, uma linha aparece ligando os pontos usados pelo algoritmo.

---

## 1. Caminho mínimo

**Algoritmo usado:** Dijkstra.

**Aplicação no jogo:** calcular a menor rota entre o jogador e uma região importante, como slime, NPC ou mercador.

**Exemplo de gameplay:** um slime pode usar esse algoritmo para encontrar o caminho mais curto até o jogador, ou um NPC pode indicar a menor rota até um objetivo.

**Complexidade:** `O(V² + E)` na versão simples implementada.

---

## 2. Caminho máximo

**Algoritmo usado:** busca em profundidade, DFS, com limite de vértices para não travar o jogo.

**Aplicação no jogo:** criar missões mais longas de exploração, fazendo o jogador passar pelo maior caminho possível sem repetir pontos.

**Exemplo de gameplay:** uma missão pode exigir que o jogador atravesse várias regiões antes de chegar ao destino final.

---

## 3. Fluxo mínimo / custo mínimo

**Algoritmo usado:** menor caminho sucessivo.

**Aplicação no jogo:** distribuir recursos ou inimigos gastando o menor custo possível.

**Exemplo de gameplay:** o jogo pode decidir por quais regiões mandar inimigos ou itens considerando o custo de cada rota.

---

## 4. Fluxo máximo

**Algoritmo usado:** Edmonds-Karp.

**Aplicação no jogo:** calcular a quantidade máxima de inimigos, recursos ou eventos que podem passar entre regiões do mapa.

**Exemplo de gameplay:** controlar quantos slimes conseguem sair de áreas de spawn e chegar até uma arena ou região central.

**Complexidade:** `O(V · E²)`.

---

## 5. Cobertura pequena

**Algoritmo usado:** Set Cover guloso.

**Aplicação no jogo:** escolher o menor número de pontos de guarda para cobrir todas as áreas importantes.

**Exemplo de gameplay:** posicionar poucos guardas, torres ou sensores para cobrir casa, mercador, NPC e áreas de slime.

---

## 6. Cobertura grande

**Algoritmo usado:** Maximum Coverage guloso.

**Aplicação no jogo:** escolher poucos pontos que cobrem a maior quantidade possível de áreas.

**Exemplo de gameplay:** com apenas dois postos de guarda, escolher os melhores locais para proteger o máximo do mapa.

---

## 7. Circuito

**Algoritmo usado:** heurística do vizinho mais próximo.

**Aplicação no jogo:** criar uma rota fechada de patrulha.

**Exemplo de gameplay:** um NPC ou inimigo sai de um ponto, passa por várias regiões importantes e retorna ao início.

---

# Resumo para apresentação

O jogo Valdoria foi usado como estudo de caso para aplicar problemas computacionais clássicos em grafos. O mapa do jogo foi tratado como um grafo, onde os pontos importantes são vértices e os caminhos possíveis são arestas. Com isso, foram aplicados problemas de caminho, fluxo, cobertura e circuito diretamente em mecânicas de jogo, como perseguição, patrulha, distribuição de recursos, posicionamento estratégico e rotas de exploração.
