# Documentar algoritmos e execução do projeto

**Labels:** documentação  
**Status:** ✅ Fechada / Concluída

## Descrição
Criar documentação explicando como rodar o jogo, quais algoritmos foram implementados, justificativa das escolhas e organização do repositório.

## Critérios de aceitação
- [x] README explica como rodar no Godot.
- [x] README informa o gênero do jogo (aventura/exploração — não é survivor).
- [x] README lista os controles do jogo.
- [x] README explica o TSP e como ele aparece no gameplay.
- [x] README explica a HashMap do inventário com exemplo de estrutura.
- [x] README explica a coleta de itens no gameplay.
- [x] README explica o QuickSort como segundo problema computacional.
- [x] Arquivo `docs/ALGORITMOS.md` documenta cada algoritmo com complexidade e justificativa.
- [x] Arquivo `docs/PROBLEMAS_COMPUTACIONAIS_APLICADOS.md` documenta os problemas de grafos.

## Arquivos
- `README.md`
- `docs/ALGORITMOS.md`
- `docs/PROBLEMAS_COMPUTACIONAIS_APLICADOS.md`
