# Implementar coleta de itens no gameplay

**Labels:** gameplay, inventário  
**Status:** ✅ Fechada / Concluída

## Descrição
Adicionar itens coletáveis no mapa e permitir que o jogador interaja com eles fisicamente para preencher o inventário. A coleta não é automática — o jogador precisa andar até o item.

## Critérios de aceitação
- [x] Itens aparecem no mapa (6 itens espalhados no level: Erva de Cura, Cristal Azul, Pena Dourada, Cogumelo Mágico, Raiz Antiga, Semente Rara).
- [x] Jogador coleta ao encostar (via Area2D com `_on_body_entered`).
- [x] Item coletado entra no inventário (chama `add_item` → HashMap).
- [x] Item coletado desaparece do mapa (`queue_free()`).
- [x] Drops de inimigos também podem ser coletados (slime dropa Gel de Slime ao morrer).
- [x] Item descartado do inventário volta ao chão e pode ser coletado novamente.

## Como funciona
1. `drop_item.tscn` é uma `Area2D` com sprite e colisão.
2. Quando o corpo do jogador entra na área, `_on_body_entered` chama `body.add_item(...)`.
3. `character.gd` delega ao `inventario.gd` via grupo `"inventario"`.
4. O item é adicionado à HashMap e `queue_free()` remove o item do mapa.

## Arquivos
- `characters/scripts/drop_item.gd` — lógica de coleta
- `characters/scenes/drop_item.tscn` — cena do item coletável
- `characters/scripts/slime.gd` — drop ao morrer
- `levels/scenes/test_level.tscn` — posicionamento dos itens no mapa
