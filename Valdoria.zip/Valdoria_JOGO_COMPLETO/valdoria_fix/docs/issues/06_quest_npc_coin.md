# Implementar quest da NPC Merry com recompensa COIN

**Labels:** gameplay, inventário  
**Status:** ✅ Fechada / Concluída

## Descrição
A NPC Merry oferece uma quest repetível ao jogador: derrotar 5 slimes para ganhar 1 COIN. O COIN entra no inventário pela HashMap e pode ser usado para comprar a Espada de Aço no mercador.

## Critérios de aceitação
- [x] Jogador se aproxima da Merry para ver o diálogo e aceitar a quest.
- [x] HUD da quest aparece no canto superior direito com barra de progresso.
- [x] Contador de slimes é atualizado a cada slime derrotado.
- [x] Ao completar 5/5, COIN é adicionado ao inventário via HashMap.
- [x] Quest reinicia automaticamente (repetível).
- [x] COIN é armazenado na HashMap com chave `"coin"`.

## Arquivos
- `characters/scripts/algorithm_gameplay_manager.gd` — lógica da quest e HUD
- `characters/scripts/mensageiro.gd` — diálogo da NPC
- `characters/scripts/slime.gd` — chama `registrar_slime_derrotado` ao morrer
