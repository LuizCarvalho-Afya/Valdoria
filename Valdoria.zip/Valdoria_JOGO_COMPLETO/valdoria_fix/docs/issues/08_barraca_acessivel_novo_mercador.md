# Reposicionar barraca e criar sprite do mercador

**Labels:** gameplay, bug  
**Status:** ✅ Fechada / Concluída

## Descrição
A barraca de venda foi reposicionada para dentro da área jogável e o mercador recebeu um sprite próprio, diferente dos NPCs já existentes no jogo.

## Critérios de aceitação
- [x] Barraca reposicionada em área acessível ao jogador.
- [x] Mercador usa sprite `merchant_npc.png` (não reutiliza o sprite da Merry).
- [x] Compra da Espada de Aço continua funcionando após o reposicionamento.
- [x] Barraca visível como objeto no cenário.

## Arquivos
- `characters/assets/merchant_npc.png`
- `characters/scenes/mercador.tscn`
- `levels/scenes/test_level.tscn`
