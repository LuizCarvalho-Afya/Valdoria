# Implementar QuickSort para ordenar o inventário

**Labels:** algoritmo, inventário, gameplay  
**Status:** ✅ Fechada / Concluída

## Descrição
Ordenar visualmente os itens do inventário por nome usando QuickSort. Escolhido como segundo problema computacional obrigatório da atividade.

## Critérios de aceitação
- [x] Inventário possui função de ordenação por nome.
- [x] Ordenação usa QuickSort (implementação própria, não a built-in do GDScript).
- [x] Jogador ativa apertando **O** com o inventário aberto.
- [x] Slots são atualizados visualmente após a ordenação.
- [x] HashMap principal (`inventario`) continua armazenando os dados — apenas `ordem_slots` muda.
- [x] Critério de desempate por ID quando dois itens têm o mesmo nome.

## Algoritmo
QuickSort com pivô central e partição em três grupos (menores, iguais, maiores).

## Complexidade
- Média: `O(n log n)`
- Pior caso: `O(n²)`

## Justificativa da escolha
Ordenação é um problema clássico de Ciência da Computação. O inventário de um jogo é um contexto natural para organizar itens por nome, raridade ou valor — o QuickSort foi implementado por nome.

## Arquivos
- `characters/scripts/inventario.gd` — funções `ordenar_por_nome_quicksort` e `_quicksort_ids_por_nome`
