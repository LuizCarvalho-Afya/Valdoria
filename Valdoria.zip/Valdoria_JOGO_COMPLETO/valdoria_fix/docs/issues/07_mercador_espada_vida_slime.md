# Implementar mercador, Espada de Aço e balanceamento de combate

**Labels:** gameplay, inventário  
**Status:** ✅ Fechada / Concluída

## Descrição
Adicionar um mercador no mapa que vende a Espada de Aço por 3 COIN. A espada aumenta o dano do jogador em 15%. Os slimes têm 20 de vida e morrem em 2 ataques com a espada inicial.

## Critérios de aceitação
- [x] Mercador aparece como NPC visível no mapa com sprite próprio.
- [x] Diálogo de compra aparece ao se aproximar (SIM / NÃO).
- [x] Compra consulta e remove COIN da HashMap do inventário.
- [x] Espada de Aço é adicionada ao inventário via HashMap após a compra.
- [x] Dano do jogador aumenta 15% ao equipar a espada.
- [x] Slimes têm 20 de vida e morrem em 2 ataques.
- [x] Barra de vida do slime aparece só quando leva dano.

## Balanceamento
- Dano inicial: 10 → slime morre em 2 ataques
- Dano com Espada de Aço: 11.5 → slime ainda morre em 2 ataques, mas o jogador fica pronto para inimigos futuros mais fortes

## Arquivos
- `characters/scripts/mercador.gd`
- `characters/scenes/mercador.tscn`
- `characters/scripts/character.gd` — `equipar_espada_melhorada`
- `characters/scripts/slime.gd` — vida e barra de vida
