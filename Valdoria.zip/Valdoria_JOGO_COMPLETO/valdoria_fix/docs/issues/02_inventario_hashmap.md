# Implementar sistema de inventário com HashMap

**Labels:** inventário, algoritmo, gameplay  
**Status:** ✅ Fechada / Concluída

## Descrição
Criar inventário usando Dictionary/HashMap com ID único para cada item coletável, com operações de adicionar, remover e consultar.

## Critérios de aceitação
- [x] Adiciona item novo.
- [x] Atualiza quantidade quando o item já existe.
- [x] Remove item por ID.
- [x] Remove item completo (zera quantidade e apaga da HashMap).
- [x] Consulta item por ID.
- [x] Consulta item por nome.
- [x] Exibe itens nos slots da interface.
- [x] Itens podem ser movidos entre slots.
- [x] Item pode ser descartado para o chão arrastando para fora do inventário.

## Estrutura principal
```gdscript
inventario = {
  "slime_gel": {
    "id": "slime_gel",
    "nome": "Gel de Slime",
    "quantidade": 3,
    "textura": Texture2D
  }
}
```

## Algoritmo / estrutura
HashMap / Dictionary — acesso O(1) por chave.

## Arquivos
- `characters/scripts/inventario.gd` — implementação completa
- `characters/scripts/character.gd` — delegação ao inventário via grupo
