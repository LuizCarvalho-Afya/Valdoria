# Implementar TSP para cálculo da rota ótima de coleta

**Labels:** algoritmo, gameplay, mapa  
**Status:** ✅ Fechada / Concluída

## Descrição
Calcular a menor rota que passe por todos os pontos de coleta marcados no mapa atual e retorne ao ponto inicial do jogador.

## Critérios de aceitação
- [x] Algoritmo recebe lista de coordenadas dos coletáveis.
- [x] Retorna ordem ótima de visitação.
- [x] Para n ≤ 15 usa solução exata com Held-Karp.
- [x] Para n > 15 usa heurística com Vizinho Mais Próximo + 2-opt.
- [x] Rota é desenhada visualmente no mapa (Line2D, tecla R).

## Algoritmo
Travelling Salesman Problem (TSP).

## Complexidade
- Exato (Held-Karp): `O(n² · 2ⁿ)`
- Heurística (vizinho mais próximo + 2-opt): `O(n²)` por iteração

## Arquivos
- `algorithms/tsp_solver.gd` — implementação do algoritmo
- `characters/scripts/algorithm_gameplay_manager.gd` — integração com o mapa
