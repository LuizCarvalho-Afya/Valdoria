# Implementar problemas computacionais em grafos no gameplay

**Labels:** algoritmo, gameplay, mapa  
**Status:** ✅ Fechada / Concluída

## Descrição
Adicionar demonstração interativa de sete problemas computacionais clássicos aplicados ao mapa do jogo, acessíveis pela tecla G durante o gameplay. O mapa é modelado como grafo: pontos importantes são vértices e caminhos entre regiões são arestas.

## Critérios de aceitação
- [x] Caminho mínimo — Dijkstra: encontra a menor rota entre o jogador e um slime/NPC.
- [x] Caminho máximo — DFS limitada: cria rota longa de exploração sem repetir vértices.
- [x] Fluxo mínimo/custo mínimo — Menor caminho sucessivo: distribui recursos com menor custo.
- [x] Fluxo máximo — Edmonds-Karp: calcula quantos slimes/recursos passam entre regiões.
- [x] Cobertura pequena — Set Cover guloso: menor número de postos de guarda para cobrir todo o mapa.
- [x] Cobertura grande — Maximum Coverage guloso: com 2 postos, cobrir o máximo do mapa.
- [x] Circuito — Vizinho mais próximo: rota fechada de patrulha de NPC ou inimigo.
- [x] Painel informativo exibe nome do algoritmo, aplicação e resultado a cada pressionamento de G.
- [x] Linha visual conecta os pontos da rota calculada no mapa.

## Complexidades
| Algoritmo | Complexidade |
|---|---|
| Dijkstra | O(V² + E) |
| DFS limitada | O(V!) com limite |
| Edmonds-Karp | O(V · E²) |
| Set Cover guloso | O(U · S) |
| Vizinho mais próximo | O(V²) |

## Arquivos
- `algorithms/graph_problems.gd` — implementação de todos os algoritmos
- `characters/scripts/algorithm_gameplay_manager.gd` — integração e UI no mapa
- `docs/PROBLEMAS_COMPUTACIONAIS_APLICADOS.md` — documentação
