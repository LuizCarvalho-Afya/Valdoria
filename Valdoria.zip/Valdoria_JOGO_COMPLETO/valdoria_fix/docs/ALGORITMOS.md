# Documentação curta dos algoritmos

## Tema do jogo
**Valdoria** é um jogo de aventura e exploração. O jogador percorre um mapa, coleta itens, derrota slimes e administra os recursos obtidos no inventário.

O jogo não usa a mecânica de survivor. O foco está na exploração, coleta e organização de itens.

---

## 1. Problema do Caixeiro Viajante — TSP

### Onde foi usado
O TSP foi integrado como mecânica de rota ótima de coleta. O jogo verifica os itens existentes no mapa e calcula a menor rota que começa no jogador, passa por todos os itens e retorna ao ponto inicial.

### Por que foi escolhido
O TSP é um problema clássico da Ciência da Computação e é NP-difícil. Ele é adequado para o jogo porque o jogador precisa decidir uma boa ordem para coletar recursos espalhados pelo mapa.

### Como funciona no projeto
- O jogador aperta **R** para recalcular a rota.
- O script coleta todos os itens do grupo `item`.
- A posição do jogador é usada como ponto inicial.
- A rota é desenhada visualmente com `Line2D`.

### Estratégia algorítmica
Para poucos pontos, foi usada solução exata com programação dinâmica no estilo Held-Karp.

Para muitos pontos, foi usada heurística:
1. Vizinho Mais Próximo: escolhe sempre o ponto mais perto ainda não visitado.
2. 2-opt: tenta melhorar a rota trocando trechos para diminuir a distância total.

### Complexidade
- Held-Karp: `O(n² · 2ⁿ)`
- Heurística: menor custo computacional, adequada para mapas com mais pontos.

---

## 2. Inventário com HashMap / Dictionary

### Onde foi usado
O inventário do jogador usa `Dictionary`, que funciona como uma HashMap.

### Justificativa
A HashMap permite acesso rápido aos itens usando uma chave única, que no projeto é o ID do item.

### Estrutura usada
```gdscript
inventario = {
  "slime_gel": {
    "id": "slime_gel",
    "nome": "Gel de Slime",
    "quantidade": 3,
    "textura": Texture2D
  }
}
```

### Operações implementadas
- adicionar item;
- remover item;
- consultar por ID;
- consultar por nome;
- exibir inventário;
- mover item nos slots;
- descartar item no chão.

---

## 3. Coleta de itens

### Onde foi usada
A coleta continua disponível pelo script `drop_item.gd`, mas os drops automáticos dos slimes foram desativados para deixar o mapa mais limpo.

Quando o personagem encosta em um item, o item é enviado para o inventário e removido do mapa.

### Por que é gameplay real
O item não é apenas criado diretamente no inventário. O jogador precisa andar pelo mapa e interagir fisicamente com o coletável.

---

## 4. Segundo problema computacional — QuickSort

### Onde foi usado
O QuickSort foi integrado no inventário.

Com o inventário aberto, o jogador aperta **O** e os itens são organizados por nome.

### Por que foi escolhido
Ordenação é um problema clássico da Ciência da Computação e combina naturalmente com um inventário de jogo.

### Como funciona
O algoritmo recebe a lista de IDs dos itens, escolhe um pivô e separa os itens em três grupos:
- menores que o pivô;
- iguais ao pivô;
- maiores que o pivô.

Depois junta os resultados recursivamente.

### Complexidade
- Média: `O(n log n)`
- Pior caso: `O(n²)`

---

## Conclusão
O projeto cumpre os requisitos da atividade porque integra algoritmos computacionais diretamente na jogabilidade. O TSP auxilia a rota de coleta, o inventário usa HashMap, a coleta ocorre no mundo do jogo e o QuickSort organiza os itens coletados.

---

## 5. Sistema de {quest da Merry}

### Onde foi usado
A Merry oferece uma quest repetível ao jogador: derrotar 5 slimes para receber COIN.

### Como funciona no gameplay
- O jogador se aproxima da Merry para ver o diálogo da missão.
- O painel da quest fica visível no canto superior direito da tela.
- Cada slime derrotado incrementa o contador da quest.
- Ao chegar em 5/5, o jogador recebe `COIN` no inventário.
- Depois da recompensa, o contador reinicia para permitir uma nova conclusão.

### Integração com os algoritmos já existentes
A recompensa entra no inventário usando a mesma HashMap/Dictionary dos itens. Assim, `coin` é armazenado como chave única no inventário, com nome, quantidade e textura.

## Sistema de compra e balanceamento de combate

O jogo recebeu uma mecânica de loja com um mercador. O jogador pode trocar 3 COIN por uma Espada de Aço, que aumenta o dano em 15%.

- Dano inicial: 10.
- Dano com Espada de Aço: 10 + 15% = 11.5.
- Vida do slime: 20.
- Resultado: com a espada inicial, o slime morre em 2 ataques; com a espada melhorada, também morre em 2 ataques, mas o jogador fica preparado para inimigos mais fortes.

Esse sistema se integra ao inventário por HashMap, pois a compra consulta e remove o item `coin` diretamente pela chave do dicionário.


### Ajuste visual da loja
A loja foi reposicionada para dentro da área jogável do mapa, deixando a barraca acessível ao jogador. O mercador recebeu um sprite próprio (`merchant_npc.png`), diferente dos NPCs já existentes.
