extends CharacterBody2D

@onready var speech_bubble_antigo: CanvasItem = get_node_or_null("CanvasGroup") as CanvasItem
@onready var npc_animation: AnimationPlayer = get_node_or_null("Animation") as AnimationPlayer

var _dialog_layer: CanvasLayer = null
var _root: Control = null
var _panel: PanelContainer = null
var _title_label: Label = null
var _body_label: Label = null
var _botao_sim: Button = null
var _botao_nao: Button = null
var _quest_manager_ref: Node = null


func _ready() -> void:
	add_to_group("npc")

	if speech_bubble_antigo:
		speech_bubble_antigo.hide()

	if npc_animation and npc_animation.has_animation("idle"):
		npc_animation.play("idle")

	_criar_ui_nitida()
	_esconder_dialogo()


func _process(_delta: float) -> void:
	if _root and _root.visible:
		_centralizar_painel()


func _on_chat_detection_body_entered(body: Node) -> void:
	if body.is_in_group("player") or body.is_in_group("character"):
		_quest_manager_ref = get_tree().get_first_node_in_group("quest_manager")
		if _quest_manager_ref and _quest_manager_ref.has_method("get_dialogo_npc"):
			show_dialogue(str(_quest_manager_ref.get_dialogo_npc()))
		else:
			show_dialogue("Olá! Derrote 5 slimes para completar minha quest e ganhar COIN.")


func _on_chat_detection_body_exited(body: Node) -> void:
	if body.is_in_group("player") or body.is_in_group("character"):
		_esconder_dialogo()


func show_dialogue(text: String) -> void:
	if _body_label:
		_body_label.text = text
	if _title_label:
		_title_label.text = "Merry"
	if _root:
		_root.show()
	if _botao_sim:
		_botao_sim.disabled = false
	_centralizar_painel()


func _aceitar_quest() -> void:
	if _quest_manager_ref and _quest_manager_ref.has_method("aceitar_quest_merry"):
		var retorno: String = str(_quest_manager_ref.aceitar_quest_merry())
		if _body_label:
			_body_label.text = retorno
		if _botao_sim:
			_botao_sim.disabled = true
		return

	_esconder_dialogo()


func _esconder_dialogo() -> void:
	if _root:
		_root.hide()


func _criar_ui_nitida() -> void:
	if _dialog_layer != null:
		return

	_dialog_layer = CanvasLayer.new()
	_dialog_layer.name = "MerryUI_Nitida"
	_dialog_layer.layer = 119
	add_child(_dialog_layer)

	_root = Control.new()
	_root.name = "MerryUIRoot"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	_dialog_layer.add_child(_root)

	_panel = PanelContainer.new()
	_panel.name = "CaixaMerry"
	_panel.custom_minimum_size = Vector2(520, 240)
	_panel.size = Vector2(520, 240)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.add_theme_stylebox_override("panel", _estilo_painel())
	_root.add_child(_panel)

	var margem: MarginContainer = MarginContainer.new()
	margem.add_theme_constant_override("margin_left", 20)
	margem.add_theme_constant_override("margin_right", 20)
	margem.add_theme_constant_override("margin_top", 15)
	margem.add_theme_constant_override("margin_bottom", 15)
	_panel.add_child(margem)

	var caixa: VBoxContainer = VBoxContainer.new()
	caixa.add_theme_constant_override("separation", 8)
	margem.add_child(caixa)

	_title_label = Label.new()
	_title_label.text = "Merry"
	_title_label.add_theme_font_size_override("font_size", 24)
	_title_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.25, 1.0))
	caixa.add_child(_title_label)

	_body_label = Label.new()
	_body_label.text = ""
	_body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_body_label.custom_minimum_size = Vector2(0, 105)
	_body_label.add_theme_font_size_override("font_size", 18)
	_body_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_body_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.65))
	_body_label.add_theme_constant_override("shadow_offset_x", 1)
	_body_label.add_theme_constant_override("shadow_offset_y", 1)
	caixa.add_child(_body_label)

	var botoes: HBoxContainer = HBoxContainer.new()
	botoes.alignment = BoxContainer.ALIGNMENT_CENTER
	botoes.add_theme_constant_override("separation", 44)
	caixa.add_child(botoes)

	_botao_sim = Button.new()
	_botao_sim.text = "SIM"
	_botao_sim.custom_minimum_size = Vector2(150, 42)
	_botao_sim.add_theme_font_size_override("font_size", 20)
	_botao_sim.add_theme_stylebox_override("normal", _estilo_botao(Color(0.14, 0.46, 0.15, 0.97), Color(0.55, 1.0, 0.42, 1)))
	_botao_sim.add_theme_stylebox_override("hover", _estilo_botao(Color(0.18, 0.55, 0.19, 1), Color(0.65, 1.0, 0.50, 1)))
	_botao_sim.add_theme_stylebox_override("pressed", _estilo_botao(Color(0.10, 0.35, 0.11, 1), Color(0.55, 1.0, 0.42, 1)))
	_botao_sim.pressed.connect(_aceitar_quest)
	botoes.add_child(_botao_sim)

	_botao_nao = Button.new()
	_botao_nao.text = "NÃO"
	_botao_nao.custom_minimum_size = Vector2(150, 42)
	_botao_nao.add_theme_font_size_override("font_size", 20)
	_botao_nao.add_theme_stylebox_override("normal", _estilo_botao(Color(0.47, 0.14, 0.11, 0.97), Color(1.0, 0.48, 0.38, 1)))
	_botao_nao.add_theme_stylebox_override("hover", _estilo_botao(Color(0.58, 0.17, 0.14, 1), Color(1.0, 0.58, 0.48, 1)))
	_botao_nao.add_theme_stylebox_override("pressed", _estilo_botao(Color(0.34, 0.09, 0.08, 1), Color(1.0, 0.48, 0.38, 1)))
	_botao_nao.pressed.connect(_esconder_dialogo)
	botoes.add_child(_botao_nao)

	_centralizar_painel()


func _estilo_painel() -> StyleBoxFlat:
	var estilo: StyleBoxFlat = StyleBoxFlat.new()
	estilo.bg_color = Color(0.035, 0.035, 0.025, 0.96)
	estilo.border_color = Color(1.0, 0.62, 0.08, 1.0)
	estilo.border_width_left = 4
	estilo.border_width_right = 4
	estilo.border_width_top = 4
	estilo.border_width_bottom = 4
	estilo.corner_radius_top_left = 14
	estilo.corner_radius_top_right = 14
	estilo.corner_radius_bottom_left = 14
	estilo.corner_radius_bottom_right = 14
	estilo.shadow_color = Color(0, 0, 0, 0.45)
	estilo.shadow_size = 8
	return estilo


func _estilo_botao(cor_fundo: Color, cor_borda: Color) -> StyleBoxFlat:
	var estilo: StyleBoxFlat = StyleBoxFlat.new()
	estilo.bg_color = cor_fundo
	estilo.border_color = cor_borda
	estilo.border_width_left = 2
	estilo.border_width_right = 2
	estilo.border_width_top = 2
	estilo.border_width_bottom = 2
	estilo.corner_radius_top_left = 8
	estilo.corner_radius_top_right = 8
	estilo.corner_radius_bottom_left = 8
	estilo.corner_radius_bottom_right = 8
	return estilo


func _centralizar_painel() -> void:
	if _panel == null:
		return
	var tela: Vector2 = get_viewport_rect().size
	var largura: float = minf(520.0, tela.x - 48.0)
	var altura: float = 240.0
	_panel.custom_minimum_size = Vector2(largura, altura)
	_panel.size = Vector2(largura, altura)
	_panel.position = Vector2((tela.x - largura) * 0.5, (tela.y - altura) * 0.5)
