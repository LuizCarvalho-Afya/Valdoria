extends Node2D

const SWORD_PLUS_TEXTURE: Texture2D = preload("res://characters/assets/sword_plus.png")

@export var preco_coin: int = 3
@export var espada_id: String = "espada_melhorada"
@export var espada_nome: String = "Espada de Aço"
@export var bonus_percentual: float = 15.0

@onready var speech_bubble_antigo: CanvasItem = get_node_or_null("CanvasGroup") as CanvasItem
@onready var merchant_animation: AnimationPlayer = get_node_or_null("Animation") as AnimationPlayer

var _player_ref: Node = null
var _dialog_layer: CanvasLayer = null
var _root: Control = null
var _panel: PanelContainer = null
var _title_label: Label = null
var _offer_label: Label = null
var _coins_label: Label = null
var _feedback_label: Label = null
var _botao_sim: Button = null
var _botao_nao: Button = null


func _ready() -> void:
	add_to_group("merchant")
	add_to_group("mercador")

	# A UI antiga ficava no mundo e estourava/ficava borrada na tela.
	# Ela fica escondida; a nova UI é criada em CanvasLayer para ficar menor e nítida.
	if speech_bubble_antigo:
		speech_bubble_antigo.hide()

	_ocultar_debug_de_colisao(self)
	_criar_ui_nitida()
	_esconder_oferta()

	if merchant_animation and merchant_animation.has_animation("RESET"):
		merchant_animation.play("RESET")


func _process(_delta: float) -> void:
	if _root and _root.visible:
		_centralizar_painel()
		_atualizar_moedas()


func _on_chat_detection_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") or body.is_in_group("character"):
		_player_ref = body
		_mostrar_oferta()


func _on_chat_detection_body_exited(body: Node2D) -> void:
	if body == _player_ref:
		_player_ref = null
		_esconder_oferta()


func _criar_ui_nitida() -> void:
	if _dialog_layer != null:
		return

	_dialog_layer = CanvasLayer.new()
	_dialog_layer.name = "MercadorUI_Nitida"
	_dialog_layer.layer = 120
	add_child(_dialog_layer)

	_root = Control.new()
	_root.name = "MercadorUIRoot"
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_STOP
	_dialog_layer.add_child(_root)

	_panel = PanelContainer.new()
	_panel.name = "CaixaMercador"
	_panel.custom_minimum_size = Vector2(520, 230)
	_panel.size = Vector2(520, 230)
	_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	_panel.add_theme_stylebox_override("panel", _estilo_painel())
	_root.add_child(_panel)

	var margem := MarginContainer.new()
	margem.add_theme_constant_override("margin_left", 20)
	margem.add_theme_constant_override("margin_right", 20)
	margem.add_theme_constant_override("margin_top", 15)
	margem.add_theme_constant_override("margin_bottom", 15)
	_panel.add_child(margem)

	var caixa := VBoxContainer.new()
	caixa.add_theme_constant_override("separation", 7)
	margem.add_child(caixa)

	_title_label = Label.new()
	_title_label.text = "Mercador"
	_title_label.add_theme_font_size_override("font_size", 24)
	_title_label.add_theme_color_override("font_color", Color(1.0, 0.82, 0.25, 1.0))
	caixa.add_child(_title_label)

	_offer_label = Label.new()
	_offer_label.text = "Quer comprar a %s?\nEla dá +%d%% de dano." % [espada_nome, int(bonus_percentual)]
	_offer_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_offer_label.add_theme_font_size_override("font_size", 19)
	_offer_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	_offer_label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.65))
	_offer_label.add_theme_constant_override("shadow_offset_x", 1)
	_offer_label.add_theme_constant_override("shadow_offset_y", 1)
	caixa.add_child(_offer_label)

	var preco_label := Label.new()
	preco_label.text = "Preço: %d COIN" % preco_coin
	preco_label.add_theme_font_size_override("font_size", 18)
	preco_label.add_theme_color_override("font_color", Color(1, 1, 1, 1))
	caixa.add_child(preco_label)

	_coins_label = Label.new()
	_coins_label.text = "Suas moedas: 0 COIN"
	_coins_label.add_theme_font_size_override("font_size", 18)
	_coins_label.add_theme_color_override("font_color", Color(0.95, 0.95, 0.95, 1))
	caixa.add_child(_coins_label)

	_feedback_label = Label.new()
	_feedback_label.text = ""
	_feedback_label.add_theme_font_size_override("font_size", 15)
	_feedback_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.35, 1))
	caixa.add_child(_feedback_label)

	var botoes := HBoxContainer.new()
	botoes.alignment = BoxContainer.ALIGNMENT_CENTER
	botoes.add_theme_constant_override("separation", 44)
	caixa.add_child(botoes)

	_botao_sim = Button.new()
	_botao_sim.text = "SIM"
	_botao_sim.custom_minimum_size = Vector2(150, 42)
	_botao_sim.add_theme_font_size_override("font_size", 20)
	_botao_sim.add_theme_stylebox_override("normal", _estilo_botao(Color(0.14, 0.46, 0.15, 0.97), Color(0.55, 1.0, 0.42, 1)))
	_botao_sim.add_theme_stylebox_override("hover", _estilo_botao(Color(0.18, 0.55, 0.19, 1), Color(0.65, 1.0, 0.50, 1)))
	_botao_sim.add_theme_stylebox_override("pressed", _estilo_botao(Color(0.10, 0.35, 0.11, 1), Color(0.55, 1.0, 0.42, 1)))
	_botao_sim.pressed.connect(_comprar_espada)
	botoes.add_child(_botao_sim)

	_botao_nao = Button.new()
	_botao_nao.text = "NÃO"
	_botao_nao.custom_minimum_size = Vector2(150, 42)
	_botao_nao.add_theme_font_size_override("font_size", 20)
	_botao_nao.add_theme_stylebox_override("normal", _estilo_botao(Color(0.47, 0.14, 0.11, 0.97), Color(1.0, 0.48, 0.38, 1)))
	_botao_nao.add_theme_stylebox_override("hover", _estilo_botao(Color(0.58, 0.17, 0.14, 1), Color(1.0, 0.58, 0.48, 1)))
	_botao_nao.add_theme_stylebox_override("pressed", _estilo_botao(Color(0.34, 0.09, 0.08, 1), Color(1.0, 0.48, 0.38, 1)))
	_botao_nao.pressed.connect(_esconder_oferta)
	botoes.add_child(_botao_nao)

	_centralizar_painel()


func _estilo_painel() -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.035, 0.035, 0.025, 0.96)
	estilo.border_color = Color(1.0, 0.62, 0.08, 1.0)
	estilo.border_width_left = 4
	estilo.border_width_right = 4
	estilo.border_width_top = 4
	estilo.border_width_bottom = 4
	estilo.corner_radius_top_left = 14
	estilo.corner_radius_top_right = 14
	estilo.corner_radius_bottom_left = 14
	estilo.corner_radius_bottom_right = 14
	estilo.shadow_color = Color(0, 0, 0, 0.45)
	estilo.shadow_size = 8
	return estilo


func _estilo_botao(cor_fundo: Color, cor_borda: Color) -> StyleBoxFlat:
	var estilo := StyleBoxFlat.new()
	estilo.bg_color = cor_fundo
	estilo.border_color = cor_borda
	estilo.border_width_left = 2
	estilo.border_width_right = 2
	estilo.border_width_top = 2
	estilo.border_width_bottom = 2
	estilo.corner_radius_top_left = 8
	estilo.corner_radius_top_right = 8
	estilo.corner_radius_bottom_left = 8
	estilo.corner_radius_bottom_right = 8
	return estilo


func _centralizar_painel() -> void:
	if _panel == null:
		return
	var tela: Vector2 = get_viewport_rect().size
	var largura: float = minf(520.0, tela.x - 48.0)
	var altura: float = 230.0
	_panel.custom_minimum_size = Vector2(largura, altura)
	_panel.size = Vector2(largura, altura)
	_panel.position = Vector2((tela.x - largura) * 0.5, (tela.y - altura) * 0.5)


func _mostrar_oferta(mensagem_extra: String = "") -> void:
	if _root == null:
		return

	_root.show()
	if _botao_sim:
		_botao_sim.disabled = false
		_botao_sim.visible = true
	if _botao_nao:
		_botao_nao.text = "NÃO"
		_botao_nao.visible = true

	if _offer_label:
		_offer_label.text = "Quer comprar a %s?\nEla dá +%d%% de dano." % [espada_nome, int(bonus_percentual)]
	if _feedback_label:
		_feedback_label.text = mensagem_extra

	_atualizar_moedas()
	_centralizar_painel()


func _esconder_oferta() -> void:
	if _root:
		_root.hide()


func _atualizar_moedas() -> void:
	if _coins_label:
		_coins_label.text = "Suas moedas: %d COIN" % _get_quantidade_coin()


func _comprar_espada() -> void:
	if _player_ref == null:
		_mostrar_oferta("Chegue mais perto para comprar.")
		return

	if _player_ref.has_method("has_espada_melhorada") and bool(_player_ref.call("has_espada_melhorada")):
		_mostrar_oferta("Você já comprou essa espada.")
		if _botao_sim:
			_botao_sim.disabled = true
		return

	var inventario_ui: Node = get_tree().get_first_node_in_group("inventario")
	if inventario_ui == null:
		_mostrar_oferta("Inventário não encontrado.")
		return

	var moedas: int = _get_quantidade_coin()
	if moedas < preco_coin:
		var faltam: int = preco_coin - moedas
		_mostrar_oferta("Faltam %d COIN." % faltam)
		return

	if not inventario_ui.has_method("remover_item") or not inventario_ui.remover_item("coin", preco_coin):
		_mostrar_oferta("Não consegui remover as COIN.")
		return

	if inventario_ui.has_method("remover_item_completo"):
		inventario_ui.remover_item_completo("sword")

	if inventario_ui.has_method("adicionar_item"):
		inventario_ui.adicionar_item(espada_id, espada_nome, SWORD_PLUS_TEXTURE, 1)

	if _player_ref.has_method("equipar_espada_melhorada"):
		_player_ref.call("equipar_espada_melhorada")

	var dano_novo: String = _get_dano_player()
	if _offer_label:
		_offer_label.text = "Compra feita!\nVocê equipou a %s." % espada_nome
	if _feedback_label:
		_feedback_label.text = "Dano novo: %s" % dano_novo
	if _botao_sim:
		_botao_sim.disabled = true
	if _botao_nao:
		_botao_nao.text = "OK"

	_atualizar_moedas()


func _get_quantidade_coin() -> int:
	if not is_inside_tree():
		return 0

	var inventario_ui: Node = get_tree().get_first_node_in_group("inventario")
	if inventario_ui == null or not inventario_ui.has_method("consultar_por_id"):
		return 0

	var item: Dictionary = inventario_ui.consultar_por_id("coin")
	if item.is_empty():
		return 0

	return int(item.get("quantidade", 0))


func _get_dano_player() -> String:
	if _player_ref != null and _player_ref.has_method("get_descricao_dano"):
		return str(_player_ref.call("get_descricao_dano"))
	return "11.5"


func _ocultar_debug_de_colisao(node: Node) -> void:
	if node is CollisionShape2D:
		var col := node as CollisionShape2D
		col.visible = false
		if col.has_method("set_debug_color"):
			col.call("set_debug_color", Color(0, 0, 0, 0))

	for child: Node in node.get_children():
		_ocultar_debug_de_colisao(child)
