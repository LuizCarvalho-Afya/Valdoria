extends Node2D

const SWORD_PLUS_TEXTURE: Texture2D = preload("res://characters/assets/sword_plus.png")

@export var preco_coin: int = 3
@export var espada_id: String = "espada_melhorada"
@export var espada_nome: String = "Espada de Aço"
@export var bonus_percentual: float = 15.0

@onready var speech_bubble: CanvasItem = $CanvasGroup
@onready var texto: Label = $CanvasGroup/Panel/Texto
@onready var botao_sim: Button = $CanvasGroup/Panel/BotaoSim
@onready var botao_nao: Button = $CanvasGroup/Panel/BotaoNao
@onready var merchant_animation: AnimationPlayer = get_node_or_null("Animation")

var _player_ref: Node = null


func _ready() -> void:
	add_to_group("merchant")
	add_to_group("mercador")

	if speech_bubble:
		speech_bubble.hide()

	_atualizar_texto_oferta()

	if merchant_animation and merchant_animation.has_animation("RESET"):
		merchant_animation.play("RESET")


func _on_chat_detection_body_entered(body: Node2D) -> void:
	if body.is_in_group("player") or body.is_in_group("character"):
		_player_ref = body
		_mostrar_oferta()


func _on_chat_detection_body_exited(body: Node2D) -> void:
	if body == _player_ref:
		_player_ref = null
		if speech_bubble:
			speech_bubble.hide()


func _mostrar_oferta(mensagem_extra: String = "") -> void:
	if speech_bubble:
		speech_bubble.show()

	if botao_sim:
		botao_sim.disabled = false
		botao_sim.visible = true

	if botao_nao:
		botao_nao.text = "NÃO"
		botao_nao.visible = true

	_atualizar_texto_oferta(mensagem_extra)


func _atualizar_texto_oferta(mensagem_extra: String = "") -> void:
	if texto == null:
		return

	var moedas: int = _get_quantidade_coin()
	var status_moedas: String = "Você tem: " + str(moedas) + " COIN."
	var dano_atual: String = ""

	if _player_ref != null and _player_ref.has_method("get_descricao_dano"):
		dano_atual = "\nDano atual: " + str(_player_ref.call("get_descricao_dano"))

	texto.text = (
		"Mercador:\n" +
		"Quer comprar a " + espada_nome + "?\n" +
		"Ela dá +" + str(int(bonus_percentual)) + "% de dano.\n" +
		"Preço: " + str(preco_coin) + " COIN. " + status_moedas +
		dano_atual
	)

	if not mensagem_extra.is_empty():
		texto.text += "\n" + mensagem_extra


func _on_botao_sim_pressed() -> void:
	_comprar_espada()


func _on_botao_nao_pressed() -> void:
	if texto:
		texto.text = "Mercador:\nSem problemas! Volte quando quiser."

	if botao_sim:
		botao_sim.visible = false
	if botao_nao:
		botao_nao.visible = false


func _comprar_espada() -> void:
	if _player_ref == null:
		_mostrar_oferta("Chegue mais perto para comprar.")
		return

	if _player_ref.has_method("has_espada_melhorada") and bool(_player_ref.call("has_espada_melhorada")):
		_mostrar_oferta("Você já comprou essa espada.")
		if botao_sim:
			botao_sim.disabled = true
		return

	var inventario_ui = get_tree().get_first_node_in_group("inventario")
	if inventario_ui == null:
		_mostrar_oferta("Inventário não encontrado.")
		return

	var moedas: int = _get_quantidade_coin()
	if moedas < preco_coin:
		var faltam: int = preco_coin - moedas
		_mostrar_oferta("Você ainda precisa de " + str(faltam) + " COIN.")
		return

	if not inventario_ui.has_method("remover_item") or not inventario_ui.remover_item("coin", preco_coin):
		_mostrar_oferta("Não consegui remover as COIN do inventário.")
		return

	if inventario_ui.has_method("adicionar_item"):
		inventario_ui.adicionar_item(espada_id, espada_nome, SWORD_PLUS_TEXTURE, 1)

	if _player_ref.has_method("equipar_espada_melhorada"):
		_player_ref.call("equipar_espada_melhorada")

	if texto:
		texto.text = (
			"Mercador:\n" +
			"Compra feita!\n" +
			"Você equipou a " + espada_nome + ".\n" +
			"Dano novo: " + _get_dano_player() + "."
		)

	if botao_sim:
		botao_sim.disabled = true
	if botao_nao:
		botao_nao.text = "OK"


func _get_quantidade_coin() -> int:
	if not is_inside_tree():
		return 0

	var inventario_ui = get_tree().get_first_node_in_group("inventario")
	if inventario_ui == null or not inventario_ui.has_method("consultar_por_id"):
		return 0

	var item: Dictionary = inventario_ui.consultar_por_id("coin")
	if item.is_empty():
		return 0

	return int(item.get("quantidade", 0))


func _get_dano_player() -> String:
	if _player_ref != null and _player_ref.has_method("get_descricao_dano"):
		return str(_player_ref.call("get_descricao_dano"))

	return "11.5"
