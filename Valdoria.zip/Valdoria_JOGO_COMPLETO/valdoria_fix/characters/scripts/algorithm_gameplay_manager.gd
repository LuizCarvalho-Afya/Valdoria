extends Node2D

# ============================================================
# GERENCIADOR DOS ALGORITMOS COMPUTACIONAIS + QUESTS
# ============================================================
# TSP: calcula a melhor rota para coletar todos os itens visíveis no mapa.
# Quest da NPC Marry: derrotar 5 slimes. Ao completar, ganha 1 COIN.
# ============================================================

const TSPSolverScript = preload("res://algorithms/tsp_solver.gd")
const GraphProblemsScript = preload("res://algorithms/graph_problems.gd")
const COIN_TEXTURE = preload("res://characters/assets/coin.png")

@export_category("TSP")
@export var recalcular_automaticamente: bool = false
@export var intervalo_recalculo: float = 0.8
@export var espessura_linha: float = 4.0
@export var mostrar_linha_tsp: bool = false
@export var mostrar_painel_tsp: bool = false

@export_category("Problemas de Grafos")
@export var mostrar_painel_grafos_ao_iniciar: bool = false
@export var mostrar_linha_grafo: bool = true
@export var espessura_linha_grafo: float = 3.0

@export_category("Quest da NPC")
@export var slimes_por_quest: int = 5
@export var recompensa_coin: int = 1

var _solver = TSPSolverScript.new()
var _graph_solver = GraphProblemsScript.new()
var _tempo := 0.0
var _linha_rota: Line2D
var _painel_tsp: Panel
var _label_info: Label
var _tsp_ativo: bool = false

var slimes_derrotados: int = 0
var quests_concluidas: int = 0
var coins_recebidas: int = 0
var _quest_ativa: bool = false
var _painel_quest: Panel
var _quest_title: Label
var _quest_progress_label: Label
var _quest_reward_label: Label
var _quest_bar: ProgressBar
var _quest_status_label: Label

var _linha_grafo: Line2D
var _painel_grafos: Panel
var _label_grafos: Label
var _indice_demo_grafo: int = 0
var _demos_grafo := [
	"caminho_minimo",
	"caminho_maximo",
	"fluxo_minimo",
	"fluxo_maximo",
	"cobertura_pequena",
	"cobertura_grande",
	"circuito"
]


func _ready() -> void:
	add_to_group("algoritmos")
	add_to_group("quest_manager")
	_criar_linha_rota()
	_criar_linha_grafo()
	if mostrar_painel_tsp:
		_criar_interface_info()
	desativar_rota_tsp()
	_criar_interface_quest()
	_criar_interface_grafos()
	_esconder_quest_hud()
	if not mostrar_painel_grafos_ao_iniciar and _painel_grafos:
		_painel_grafos.hide()


func _process(delta: float) -> void:
	if not is_inside_tree():
		return

	if Input.is_action_just_pressed("rota_tsp"):
		alternar_rota_tsp()

	if Input.is_action_just_pressed("problemas_grafos"):
		executar_proximo_problema_grafo()

	if recalcular_automaticamente:
		_tempo += delta
		if _tempo >= intervalo_recalculo:
			_tempo = 0.0
			atualizar_rota_tsp()


# ============================================================
# TSP / CAIXEIRO VIAJANTE
# ============================================================
func alternar_rota_tsp() -> void:
	if _tsp_ativo:
		desativar_rota_tsp()
		return

	ativar_rota_tsp()


func ativar_rota_tsp() -> void:
	_tsp_ativo = true
	if _linha_rota:
		_linha_rota.visible = mostrar_linha_tsp
	if _painel_tsp:
		_painel_tsp.show()
	atualizar_rota_tsp()


func desativar_rota_tsp() -> void:
	_tsp_ativo = false
	if _linha_rota:
		_linha_rota.clear_points()
		_linha_rota.visible = false
	if _painel_tsp:
		_painel_tsp.hide()


func atualizar_rota_tsp() -> void:
	if not is_inside_tree() or not _tsp_ativo:
		return

	var tree := get_tree()
	if tree == null:
		return

	var jogador := tree.get_first_node_in_group("player") as Node2D
	if jogador == null:
		_atualizar_texto("TSP: jogador não encontrado.")
		return

	var pontos := _coletar_pontos_de_itens()

	if pontos.is_empty():
		_linha_rota.clear_points()
		_atualizar_texto("TSP: não há itens no mapa. Derrote slimes ou use os coletáveis.")
		return

	var resultado: Dictionary = _solver.resolver(jogador.global_position, pontos)
	_desenhar_rota(resultado.get("rota", []))

	var metodo := str(resultado.get("metodo", "TSP"))
	var distancia := float(resultado.get("distancia", 0.0))
	_atualizar_texto(
		"Rota TSP | " + metodo +
		" | Pontos: " + str(pontos.size()) +
		" | Distância: " + str(round(distancia)) +
		"\nR = recalcular rota | E = inventário | O = ordenar inventário"
	)


func _coletar_pontos_de_itens() -> Array:
	var pontos: Array = []

	if not is_inside_tree():
		return pontos

	var tree := get_tree()
	if tree == null:
		return pontos

	for item in tree.get_nodes_in_group("item"):
		if item is Node2D and item.is_inside_tree() and not item.is_queued_for_deletion():
			pontos.append((item as Node2D).global_position)

	return pontos


func _desenhar_rota(rota: Array) -> void:
	if _linha_rota == null:
		return

	_linha_rota.clear_points()

	if not mostrar_linha_tsp:
		return

	for ponto in rota:
		if ponto is Vector2:
			_linha_rota.add_point(to_local(ponto))


func _criar_linha_rota() -> void:
	_linha_rota = Line2D.new()
	_linha_rota.name = "LinhaRotaTSP"
	_linha_rota.width = espessura_linha
	_linha_rota.default_color = Color(0.1, 0.9, 1.0, 0.85)
	_linha_rota.visible = false
	_linha_rota.z_index = 999
	add_child(_linha_rota)


func _criar_interface_info() -> void:
	var canvas := CanvasLayer.new()
	canvas.name = "CanvasAlgoritmos"
	add_child(canvas)

	var painel: Panel = Panel.new()
	painel.name = "PainelInfoAlgoritmos"
	painel.position = Vector2(24, 24)
	painel.size = Vector2(760, 82)
	canvas.add_child(painel)
	_painel_tsp = painel

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.02, 0.06, 0.09, 0.78)
	estilo.border_color = Color(0.1, 0.9, 1.0, 0.9)
	estilo.set_border_width_all(2)
	estilo.set_corner_radius_all(14)
	painel.add_theme_stylebox_override("panel", estilo)

	_label_info = Label.new()
	_label_info.name = "LabelInfoAlgoritmos"
	_label_info.position = Vector2(14, 10)
	_label_info.size = Vector2(735, 65)
	_label_info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_label_info.add_theme_color_override("font_color", Color(0.9, 1.0, 1.0, 1.0))
	painel.add_child(_label_info)


func _atualizar_texto(texto: String) -> void:
	if _label_info:
		_label_info.text = texto


# ============================================================
# QUEST DA NPC MARRY
# ============================================================
func registrar_slime_derrotado() -> void:
	if not _quest_ativa:
		return

	slimes_derrotados += 1

	if slimes_derrotados >= slimes_por_quest:
		_completar_quest_slimes()
		return

	_atualizar_quest_hud("Slime derrotado! Continue a quest da Merry.")


func _completar_quest_slimes() -> void:
	quests_concluidas += 1
	slimes_derrotados = 0
	_quest_ativa = false
	_dar_recompensa_coin()
	_esconder_quest_hud()
	if not mostrar_painel_grafos_ao_iniciar and _painel_grafos:
		_painel_grafos.hide()
	print("QUEST DA MERRY COMPLETA! Você ganhou +", recompensa_coin, " COIN.")


func _dar_recompensa_coin() -> void:
	coins_recebidas += recompensa_coin

	if not is_inside_tree():
		return

	var tree := get_tree()
	if tree == null:
		return

	var inventario_ui = tree.get_first_node_in_group("inventario")
	if inventario_ui and inventario_ui.has_method("adicionar_item"):
		inventario_ui.adicionar_item("coin", "COIN", COIN_TEXTURE, recompensa_coin)
		return

	var jogador = tree.get_first_node_in_group("player")
	if jogador and jogador.has_method("add_item"):
		jogador.add_item("coin", "COIN", COIN_TEXTURE, recompensa_coin)


func get_dialogo_npc() -> String:
	var faltam: int = maxi(slimes_por_quest - slimes_derrotados, 0)
	return (
		"Olá, aventureiro! Eu sou Merry.\n" +
		"Quest da Merry: derrotar 5 slimes.\n" +
		"Progresso: " + str(slimes_derrotados) + "/" + str(slimes_por_quest) + "\n" +
		"Faltam: " + str(faltam) + " slime(s)\n" +
		"Recompensa: +" + str(recompensa_coin) + " COIN\n" +
		"Concluída(s): " + str(quests_concluidas) + " vez(es)"
	)


func aceitar_quest_merry() -> String:
	if _quest_ativa:
		_atualizar_quest_hud("A quest da Merry já está ativa.")
		return "A quest da Merry já está ativa.\nDerrote 5 slimes para ganhar COIN."

	ativar_quest_merry()
	return "Quest aceita!\nDerrote 5 slimes para ganhar +" + str(recompensa_coin) + " COIN."


func is_quest_merry_ativa() -> bool:
	return _quest_ativa


func ativar_quest_merry() -> void:
	_quest_ativa = true

	if _painel_quest:
		_painel_quest.show()

	_atualizar_quest_hud("Quest aceita! Derrote 5 slimes para ganhar COIN.")


func _esconder_quest_hud() -> void:
	if _painel_quest:
		_painel_quest.hide()


func _criar_interface_quest() -> void:
	var canvas := CanvasLayer.new()
	canvas.name = "CanvasQuestNPC"
	add_child(canvas)

	var painel := Panel.new()
	_painel_quest = painel
	painel.name = "PainelQuestMerry"
	painel.set_anchors_preset(Control.PRESET_TOP_RIGHT)
	painel.offset_left = -454
	painel.offset_top = 24
	painel.offset_right = -24
	painel.offset_bottom = 190
	canvas.add_child(painel)

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.10, 0.07, 0.03, 0.88)
	estilo.border_color = Color(1.0, 0.74, 0.20, 0.96)
	estilo.set_border_width_all(3)
	estilo.set_corner_radius_all(18)
	painel.add_theme_stylebox_override("panel", estilo)

	_quest_title = Label.new()
	_quest_title.name = "TituloQuest"
	_quest_title.position = Vector2(18, 12)
	_quest_title.size = Vector2(390, 28)
	_quest_title.text = "{quest da Merry}"
	_quest_title.add_theme_font_size_override("font_size", 22)
	_quest_title.add_theme_color_override("font_color", Color(1.0, 0.88, 0.40, 1.0))
	painel.add_child(_quest_title)

	_quest_progress_label = Label.new()
	_quest_progress_label.name = "ProgressoQuest"
	_quest_progress_label.position = Vector2(18, 46)
	_quest_progress_label.size = Vector2(390, 28)
	_quest_progress_label.add_theme_font_size_override("font_size", 17)
	_quest_progress_label.add_theme_color_override("font_color", Color(1.0, 0.96, 0.82, 1.0))
	painel.add_child(_quest_progress_label)

	_quest_bar = ProgressBar.new()
	_quest_bar.name = "BarraQuest"
	_quest_bar.position = Vector2(18, 78)
	_quest_bar.size = Vector2(390, 24)
	_quest_bar.min_value = 0
	_quest_bar.max_value = slimes_por_quest
	_quest_bar.show_percentage = false
	painel.add_child(_quest_bar)

	_quest_reward_label = Label.new()
	_quest_reward_label.name = "RecompensaQuest"
	_quest_reward_label.position = Vector2(18, 108)
	_quest_reward_label.size = Vector2(390, 24)
	_quest_reward_label.add_theme_font_size_override("font_size", 15)
	_quest_reward_label.add_theme_color_override("font_color", Color(0.95, 0.86, 0.60, 1.0))
	painel.add_child(_quest_reward_label)

	_quest_status_label = Label.new()
	_quest_status_label.name = "StatusQuest"
	_quest_status_label.position = Vector2(18, 132)
	_quest_status_label.size = Vector2(390, 25)
	_quest_status_label.add_theme_font_size_override("font_size", 14)
	_quest_status_label.add_theme_color_override("font_color", Color(0.78, 1.0, 0.72, 1.0))
	painel.add_child(_quest_status_label)


func _atualizar_quest_hud(status: String = "") -> void:
	if _quest_progress_label:
		_quest_progress_label.text = "Derrote slimes: " + str(slimes_derrotados) + "/" + str(slimes_por_quest)

	if _quest_bar:
		_quest_bar.max_value = slimes_por_quest
		_quest_bar.value = slimes_derrotados

	if _quest_reward_label:
		_quest_reward_label.text = "Recompensa: +" + str(recompensa_coin) + " COIN | Concluídas: " + str(quests_concluidas)

	if _quest_status_label:
		_quest_status_label.text = status


func _animar_painel_quest() -> void:
	if _quest_title == null:
		return

	var painel := _quest_title.get_parent() as Control
	if painel == null:
		return

	painel.scale = Vector2(1.03, 1.03)
	var tween := create_tween()
	tween.tween_property(painel, "scale", Vector2.ONE, 0.25)


# ============================================================
# PROBLEMAS COMPUTACIONAIS DO ARTIGO
# ============================================================
func executar_proximo_problema_grafo() -> void:
	if _demos_grafo.is_empty():
		return

	var demo: String = _demos_grafo[_indice_demo_grafo % _demos_grafo.size()]
	_indice_demo_grafo += 1

	var resultado := _executar_demo_grafo(demo)
	var texto: String = resultado.get("texto", "")
	var rota_nomes: Array = resultado.get("rota_nomes", [])
	var pontos: Dictionary = resultado.get("pontos", {})

	if _painel_grafos:
		_painel_grafos.show()

	if _label_grafos:
		_label_grafos.text = texto + "\n\nPressione G para ver o próximo problema computacional."

	_desenhar_linha_grafo_por_nomes(rota_nomes, pontos)


func _executar_demo_grafo(demo: String) -> Dictionary:
	var pontos := _coletar_pontos_algoritmos()
	var grafo := _montar_grafo_do_mapa(pontos)
	var destino := _pegar_destino_slime(pontos)

	match demo:
		"caminho_minimo":
			var r_min: Dictionary = _graph_solver.caminho_minimo(grafo, "Jogador", destino)
			return {
				"texto": "CAMINHO MÍNIMO — Dijkstra\nAplicação: o slime/NPC escolhe a menor rota entre regiões do mapa.\nOrigem: Jogador | Destino: " + destino +
				"\nCaminho: " + _formatar_lista(r_min.get("caminho", [])) +
				"\nCusto/distância: " + str(round(float(r_min.get("custo", 0.0)))),
				"rota_nomes": r_min.get("caminho", []),
				"pontos": pontos
			}

		"caminho_maximo":
			var r_max: Dictionary = _graph_solver.caminho_maximo_simples(grafo, "Jogador", destino, 8)
			return {
				"texto": "CAMINHO MÁXIMO — busca DFS limitada\nAplicação: criar uma rota longa de exploração/missão sem repetir pontos.\nOrigem: Jogador | Destino: " + destino +
				"\nCaminho: " + _formatar_lista(r_max.get("caminho", [])) +
				"\nCusto/distância: " + str(round(float(r_max.get("custo", 0.0)))),
				"rota_nomes": r_max.get("caminho", []),
				"pontos": pontos
			}

		"fluxo_minimo":
			var rede_min := _rede_fluxo_exemplo()
			var custos := _rede_custos_exemplo()
			var fluxo_min: Dictionary = _graph_solver.fluxo_custo_minimo(rede_min, custos, "Base", "Arena", 4.0)
			return {
				"texto": "FLUXO MÍNIMO / CUSTO MÍNIMO\nAplicação: distribuir 4 recursos/inimigos pelo mapa gastando o menor custo possível.\nFluxo enviado: " + str(fluxo_min.get("fluxo", 0.0)) +
				" de " + str(fluxo_min.get("demanda", 0.0)) +
				"\nCusto total: " + str(round(float(fluxo_min.get("custo", 0.0)))) +
				"\nCaminhos usados: " + _formatar_caminhos_fluxo(fluxo_min.get("caminhos", [])),
				"rota_nomes": [],
				"pontos": pontos
			}

		"fluxo_maximo":
			var rede_max := _rede_fluxo_exemplo()
			var fluxo_max: Dictionary = _graph_solver.fluxo_maximo(rede_max, "Base", "Arena")
			return {
				"texto": "FLUXO MÁXIMO — Edmonds-Karp\nAplicação: descobrir quantos inimigos/recursos podem atravessar a rede do mapa por vez.\nFluxo máximo: " + str(fluxo_max.get("valor", 0.0)) +
				"\nCaminhos aumentantes: " + _formatar_caminhos_fluxo(fluxo_max.get("caminhos", [])),
				"rota_nomes": [],
				"pontos": pontos
			}

		"cobertura_pequena":
			var cobertura_min: Dictionary = _graph_solver.cobertura_conjuntos_minima(_universo_cobertura(), _subconjuntos_cobertura())
			return {
				"texto": "COBERTURA PEQUENA — Greedy Set Cover\nAplicação: escolher o menor número de postos/guardas para cobrir as áreas do mapa.\nCobertura escolhida: " + _formatar_lista(cobertura_min.get("escolhidos", [])) +
				"\nÁreas cobertas: " + _formatar_lista(cobertura_min.get("cobertos", [])) +
				"\nFaltando cobrir: " + _formatar_lista(cobertura_min.get("faltando", [])),
				"rota_nomes": cobertura_min.get("escolhidos", []),
				"pontos": _pontos_cobertura_visual(pontos)
			}

		"cobertura_grande":
			var cobertura_max: Dictionary = _graph_solver.cobertura_maxima_k(_universo_cobertura(), _subconjuntos_cobertura(), 2)
			return {
				"texto": "COBERTURA GRANDE — Maximum Coverage\nAplicação: com apenas 2 postos, cobrir o máximo de regiões importantes.\nCobertura escolhida: " + _formatar_lista(cobertura_max.get("escolhidos", [])) +
				"\nÁreas cobertas: " + _formatar_lista(cobertura_max.get("cobertos", [])) +
				"\nQuantidade coberta: " + str(cobertura_max.get("quantidade", 0)),
				"rota_nomes": cobertura_max.get("escolhidos", []),
				"pontos": _pontos_cobertura_visual(pontos)
			}

		"circuito":
			var circuito: Dictionary = _graph_solver.circuito_guloso(_grafo_circuito_itens())
			return {
				"texto": "CIRCUITO / CICLO HAMILTONIANO APROXIMADO\nAplicação: fazer uma patrulha/rota que passe por todos os pontos e volte ao início.\nCircuito: " + _formatar_lista(circuito.get("caminho", [])) +
				"\nCusto total: " + str(round(float(circuito.get("custo", 0.0)))),
				"rota_nomes": circuito.get("caminho", []),
				"pontos": _pontos_circuito_visual(pontos)
			}

		_:
			return {"texto": "Demo não encontrada.", "rota_nomes": [], "pontos": pontos}


func _coletar_pontos_algoritmos() -> Dictionary:
	var pontos: Dictionary = {}

	if not is_inside_tree():
		return pontos

	var tree := get_tree()
	if tree == null:
		return pontos

	var jogador := tree.get_first_node_in_group("player") as Node2D
	if jogador:
		pontos["Jogador"] = jogador.global_position

	var mercador := tree.get_first_node_in_group("mercador") as Node2D
	if mercador:
		pontos["Mercador"] = mercador.global_position

	var merry := _buscar_no_por_nome(tree.current_scene, "Mensageiro") as Node2D
	if merry:
		pontos["Merry"] = merry.global_position

	var casa := _buscar_no_por_nome(tree.current_scene, "ObjectsTerrain") as Node2D
	if casa:
		pontos["Casa"] = casa.global_position + Vector2(32, 16)

	var slimes: Array = []
	for slime in tree.get_nodes_in_group("slime"):
		if slime is Node2D:
			slimes.append(slime)

	for i in range(mini(4, slimes.size())):
		pontos["Slime" + str(i + 1)] = (slimes[i] as Node2D).global_position

	if pontos.is_empty():
		pontos = {
			"Jogador": Vector2(254, 214),
			"Merry": Vector2(192, 67),
			"Mercador": Vector2(150, 165),
			"Casa": Vector2(344, 92),
			"Slime1": Vector2(430, 170),
			"Slime2": Vector2(490, 226),
			"Slime3": Vector2(392, 308),
			"Slime4": Vector2(520, 340)
		}

	return pontos


func _montar_grafo_do_mapa(pontos: Dictionary) -> Dictionary:
	var grafo: Dictionary = {}
	for chave in pontos.keys():
		grafo[chave] = {}

	_conectar_grafo(grafo, pontos, "Jogador", "Merry")
	_conectar_grafo(grafo, pontos, "Jogador", "Mercador")
	_conectar_grafo(grafo, pontos, "Jogador", "Casa")
	_conectar_grafo(grafo, pontos, "Merry", "Casa")
	_conectar_grafo(grafo, pontos, "Merry", "Slime2")
	_conectar_grafo(grafo, pontos, "Casa", "Mercador")
	_conectar_grafo(grafo, pontos, "Mercador", "Slime1")
	_conectar_grafo(grafo, pontos, "Mercador", "Slime2")
	_conectar_grafo(grafo, pontos, "Casa", "Slime3")
	_conectar_grafo(grafo, pontos, "Slime2", "Slime3")
	_conectar_grafo(grafo, pontos, "Slime3", "Slime4")
	_conectar_grafo(grafo, pontos, "Slime1", "Slime4")

	return grafo


func _conectar_grafo(grafo: Dictionary, pontos: Dictionary, a: String, b: String) -> void:
	if not pontos.has(a) or not pontos.has(b):
		return

	var pa: Vector2 = pontos[a]
	var pb: Vector2 = pontos[b]
	var dist: float = pa.distance_to(pb)
	grafo[a][b] = dist
	grafo[b][a] = dist


func _pegar_destino_slime(pontos: Dictionary) -> String:
	for nome in ["Slime1", "Slime2", "Slime3", "Slime4"]:
		if pontos.has(nome):
			return nome
	return "Mercador"


func _criar_linha_grafo() -> void:
	_linha_grafo = Line2D.new()
	_linha_grafo.name = "LinhaProblemasGrafos"
	_linha_grafo.width = espessura_linha_grafo
	_linha_grafo.default_color = Color(1.0, 0.75, 0.2, 0.9)
	_linha_grafo.visible = false
	_linha_grafo.z_index = 998
	add_child(_linha_grafo)


func _desenhar_linha_grafo_por_nomes(nomes: Array, pontos: Dictionary) -> void:
	if _linha_grafo == null:
		return

	_linha_grafo.clear_points()
	_linha_grafo.visible = false

	if not mostrar_linha_grafo or nomes.is_empty():
		return

	for nome in nomes:
		if pontos.has(nome):
			_linha_grafo.add_point(to_local(pontos[nome]))

	if _linha_grafo.get_point_count() >= 2:
		_linha_grafo.visible = true


func _criar_interface_grafos() -> void:
	var canvas := CanvasLayer.new()
	canvas.name = "CanvasProblemasGrafos"
	add_child(canvas)

	var painel := Panel.new()
	painel.name = "PainelProblemasGrafos"
	painel.set_anchors_preset(Control.PRESET_BOTTOM_LEFT)
	painel.offset_left = 24
	painel.offset_top = -220
	painel.offset_right = 540
	painel.offset_bottom = -24
	canvas.add_child(painel)
	_painel_grafos = painel

	var estilo := StyleBoxFlat.new()
	estilo.bg_color = Color(0.06, 0.05, 0.02, 0.88)
	estilo.border_color = Color(1.0, 0.72, 0.18, 0.95)
	estilo.set_border_width_all(3)
	estilo.set_corner_radius_all(18)
	painel.add_theme_stylebox_override("panel", estilo)

	_label_grafos = Label.new()
	_label_grafos.name = "LabelProblemasGrafos"
	_label_grafos.position = Vector2(16, 14)
	_label_grafos.size = Vector2(500, 180)
	_label_grafos.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_label_grafos.add_theme_font_size_override("font_size", 15)
	_label_grafos.add_theme_color_override("font_color", Color(1.0, 0.97, 0.88, 1.0))
	painel.add_child(_label_grafos)


func _rede_fluxo_exemplo() -> Dictionary:
	return {
		"Base": {"Norte": 5.0, "Sul": 4.0},
		"Norte": {"Centro": 3.0, "Arena": 2.0},
		"Sul": {"Centro": 2.0, "Arena": 3.0},
		"Centro": {"Arena": 4.0},
		"Arena": {}
	}


func _rede_custos_exemplo() -> Dictionary:
	return {
		"Base": {"Norte": 2.0, "Sul": 1.0},
		"Norte": {"Centro": 2.0, "Arena": 3.0},
		"Sul": {"Centro": 1.0, "Arena": 4.0},
		"Centro": {"Arena": 1.0},
		"Arena": {}
	}


func _universo_cobertura() -> Array:
	return ["Jogador", "Merry", "Mercador", "Casa", "Slime1", "Slime2", "Slime3", "Slime4"]


func _subconjuntos_cobertura() -> Dictionary:
	return {
		"Posto_Casa": ["Jogador", "Merry", "Casa"],
		"Posto_Mercado": ["Jogador", "Mercador", "Slime1"],
		"Posto_Leste": ["Casa", "Slime2", "Slime3"],
		"Posto_Sul": ["Slime1", "Slime3", "Slime4"],
		"Posto_Oeste": ["Merry", "Slime2", "Slime4"]
	}


func _pontos_cobertura_visual(pontos_mapa: Dictionary) -> Dictionary:
	var pontos: Dictionary = {}
	pontos["Posto_Casa"] = pontos_mapa.get("Casa", Vector2.ZERO)
	pontos["Posto_Mercado"] = pontos_mapa.get("Mercador", Vector2.ZERO)
	pontos["Posto_Leste"] = pontos_mapa.get("Slime2", Vector2.ZERO)
	pontos["Posto_Sul"] = pontos_mapa.get("Slime4", Vector2.ZERO)
	pontos["Posto_Oeste"] = pontos_mapa.get("Merry", Vector2.ZERO)
	return pontos


func _grafo_circuito_itens() -> Dictionary:
	return {
		"Jogador": {"Merry": 10.0, "Mercador": 18.0, "Casa": 20.0, "Slime1": 23.0},
		"Merry": {"Jogador": 10.0, "Mercador": 14.0, "Casa": 12.0, "Slime2": 16.0},
		"Mercador": {"Jogador": 18.0, "Merry": 14.0, "Slime1": 9.0, "Slime3": 15.0},
		"Casa": {"Jogador": 20.0, "Merry": 12.0, "Slime3": 11.0, "Slime4": 19.0},
		"Slime1": {"Jogador": 23.0, "Mercador": 9.0, "Slime2": 8.0, "Slime4": 10.0},
		"Slime2": {"Merry": 16.0, "Slime1": 8.0, "Slime3": 7.0, "Slime4": 12.0},
		"Slime3": {"Mercador": 15.0, "Casa": 11.0, "Slime2": 7.0, "Slime4": 6.0},
		"Slime4": {"Casa": 19.0, "Slime1": 10.0, "Slime2": 12.0, "Slime3": 6.0}
	}


func _pontos_circuito_visual(pontos_mapa: Dictionary) -> Dictionary:
	return pontos_mapa.duplicate(true)


func _formatar_lista(lista: Array) -> String:
	if lista.is_empty():
		return "-"
	var partes: Array[String] = []
	for item in lista:
		partes.append(str(item))
	return " -> ".join(partes)


func _formatar_caminhos_fluxo(caminhos: Array) -> String:
	if caminhos.is_empty():
		return "-"
	var partes: Array[String] = []
	for c in caminhos:
		if c is Dictionary:
			var caminho: Array = c.get("caminho", [])
			var valor: float = float(c.get("valor", 0.0))
			partes.append(_formatar_lista(caminho) + " (" + str(valor) + ")")
	return " | ".join(partes)


func _buscar_no_por_nome(no: Node, nome: String) -> Node:
	if no == null:
		return null
	if no.name == nome:
		return no
	for filho in no.get_children():
		var achado := _buscar_no_por_nome(filho, nome)
		if achado:
			return achado
	return null
